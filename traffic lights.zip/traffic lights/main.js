function lights() {
    var colors = document.getElementsByClassName('colors');
    colors[0].style.background = 'red';
    colors[1].style.background = 'gray';
    colors[2].style.background = 'gray';

    function changeToYellow() {
        colors[1].style.background = 'yellow';

    }
    function changeToGreen() {
        colors[0].style.background = 'gray';
        colors[1].style.background = 'gray';
        colors[2].style.background = 'green';
    }
    var x = setTimeout(changeToYellow, 3000);
    var y = setTimeout(changeToGreen, 5000);

    var start = setInterval(lights, 8000);

}
lights();