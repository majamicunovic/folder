window.addEventListener('load',shuffleAll);

function shuffleAll (){
    let allLevelDivs=document.querySelectorAll('[class*="level"]');
    for(const levelDiv of allLevelDivs){
        let allSlices=levelDiv.querySelectorAll('[class*="img-holder"]');
        let orderArray=[];
        for(let i=0;i<allSlices.length;i++){
            orderArray.push(i+1)
        }

        for(let i=0;i<allSlices.length;i++){
            let rand=Math.floor(Math.random()*orderArray.length)
            allSlices[i].style.order=orderArray[rand];
            orderArray.splice(rand,1);
        }
     
    }
    addClicksToSlices();
}
function addClicksToSlices(){
    let allSlices=document.querySelectorAll('[class*="img-holder"]');
    for(const slice of allSlices){
        slice.addEventListener('click', selectMe)
    }
}
function selectMe(){
    this.style.border="2px solid red"
}


