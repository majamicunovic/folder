package com.filmoteka.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MajaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MajaApplication.class, args);
	}

}
