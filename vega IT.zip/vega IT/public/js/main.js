"use strict";

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

var slideIndex = 1;
var slides = document.getElementsByClassName('slide');
var dots = document.getElementsByClassName('dot');
var bars = document.getElementsByClassName('bars');
bars[0].addEventListener('click', function (event) {
  event.currentTarget.classList.toggle('change');
});

var _loop = function _loop(i) {
  //const n = [].indexOf.call(dots, dot);
  dots[i].addEventListener('click', function () {
    var index = i + 1;
    showSlides(slideIndex = index);
  });
};

for (var i = 0; i < dots.length; i++) {
  _loop(i);
}

var initSlides = function initSlides() {
  fetch('../slides.json').then(function (response) {
    return response.json();
  }).then(function (data) {
    for (var _i = 0; _i < data.length; _i++) {
      slides[_i].firstChild('img').src = data[_i].url;
    }
  })["catch"](function (err) {
    return console.log(error);
  });
};

var plusSlides = function plusSlides(n) {
  showSlides(slideIndex += n);
};

var showSlides = function showSlides(n) {
  if (n > slides.length) {
    slideIndex = 1;
  }

  if (n < 1) {
    slideIndex = slides.length;
  }

  var _iterator = _createForOfIteratorHelper(slides),
      _step;

  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var slide = _step.value;
      slide.style.display = 'none';
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }

  var _iterator2 = _createForOfIteratorHelper(dots),
      _step2;

  try {
    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
      var dot = _step2.value;
      dot.classList.remove('active');
    }
  } catch (err) {
    _iterator2.e(err);
  } finally {
    _iterator2.f();
  }

  slides[slideIndex - 1].style.display = 'block';
  dots[slideIndex - 1].classList.add('active');
}; // initSlides();


showSlides(slideIndex);
