var current=document.getElementById('current');
var picture=document.getElementsByClassName('thumb');

for(var i=0;i<picture.length;i++){
    picture[i].addEventListener ('click', display);
}
function display(){
    var sl=this.getAttribute('src');
    current.setAttribute('src', sl);
    current.style.opacity='0.7';
    
}