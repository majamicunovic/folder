package sprintovi.model;

public enum UserRole {
	ADMIN,
	USER,
	TRAINER
}
