package sprintovi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class SprintoviApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		 SpringApplication.run(SprintoviApplication.class, args);
	}

}
