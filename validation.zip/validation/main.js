//inpl..email.message..sendBtn

var ime = document.getElementById('inpl');
var email = document.getElementById('email');
var msg = document.getElementById('message');
var send = document.getElementById('sendBtn');

send.addEventListener('click', validacija);
ime.addEventListener('focus', clear);
email.addEventListener('focus', clear);
msg.addEventListener('focus', clear);

function validacija() {
    if (ime.value == "") {
        ime.value == "this field is required";
        ime.style.color = 'red';
    };
    if (email.value == "") {
        email.value == "this field is required";
        email.style.color = 'red';
    };
    if (msg.value == "") {
        msg.value == "this field is required";
        msg.style.color = 'red';
    };
}
function clear() {
    this.value = "";
    this.style.color = 'black';

}