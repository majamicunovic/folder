let slideIndex = 1;
const slides = document.getElementsByClassName('slide');
const dots = document.getElementsByClassName('dot');
const bars = document.getElementsByClassName('bars');

bars[0].addEventListener('click', event => {
    event.currentTarget.classList.toggle('change');
});

for (let i = 0; i < dots.length; i++) {
    //const n = [].indexOf.call(dots, dot);
    dots[i].addEventListener('click', () => {
        const index = i + 1;
        showSlides(slideIndex = index);
    });
}

const initSlides = () => {
    fetch('../slides.json')
    .then(response => response.json())
    .then(data => {
        for (let i = 0; i < data.length; i++) {
            slides[i].firstChild('img').src = data[i].url;
        }
    })
    .catch(err => console.log(error));
}

const plusSlides = (n) => {
  showSlides(slideIndex += n);
}

const showSlides = (n) => {
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}

  for (const slide  of slides) {
      slide.style.display = 'none';
  }
  for (const dot of dots) {
      dot.classList.remove('active');
  }

  slides[slideIndex-1].style.display = 'block';
  dots[slideIndex-1].classList.add('active');
}

// initSlides();
showSlides(slideIndex);