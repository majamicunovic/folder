angular.module('mainController',[])
.controller('mainCtrl', function ($scope,$http){
    $scope.cakes = [];
    $scope.activeCake={};
    $http({
        method: "get",
        url: "https://raw.githubusercontent.com/majamicunovic/folder/main/cakes.json"
    }).then(function (result) {
        $scope.cakes = result.data;
    }, function (error) {
        console.log(error);
    })
    $scope.display=function(cake){
        $scope.activeCake=cake;
    }
})