var app = angular.module('cakes', ['mainController']);



