package com.ftninformatika.jwd.modul3.cinema.enumeration;

public enum KorisnickaUloga {
    ADMIN,
    KORISNIK
}
