
var timer=document.getElementById('timer');
var loop;


function displayTime (){
    var sada=new Date();
    var h=sada.getHours();
    var m=sada.getMinutes();
    var s=sada.getSeconds();

    timer.innerHTML=h+'h:'+m+'m:'+s+'s:'

}
loop=setInterval(displayTime, 1000);